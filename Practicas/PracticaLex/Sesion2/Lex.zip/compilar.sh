lex traductor.l
gcc -o salida lex.yy.c -ll