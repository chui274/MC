#include "stdio.h"

/**
 Ejemplo de traducción a HTML
 
**/


/*
 
 SOFIA FERNANDEZ MORENO
 
 MODELOS DE COMPUTACIÓN

*/

void escribir_header (FILE *);
void escribir_final (FILE *);
void escribir_hola (FILE *);
