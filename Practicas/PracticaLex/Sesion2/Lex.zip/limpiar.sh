rm *.out
rm lex.yy.c
rm *.html
rm *.o